# Contador-New-Year
Cuenta regresiva año nuevo, usando HTML y Javascript

**Tutorial**
<br/><br/>
https://youtu.be/gBYGtL73DAo
<br/><br/>
**Demo**

![image](https://drive.google.com/uc?export=view&id=1_7Go_HB5Ou5ikeIuSKEKr-o4vdVI0D-i)
